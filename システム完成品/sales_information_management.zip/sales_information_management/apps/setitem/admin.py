from unicodedata import category
from django.contrib import admin
from .models import SetItems

admin.site.register(SetItems)