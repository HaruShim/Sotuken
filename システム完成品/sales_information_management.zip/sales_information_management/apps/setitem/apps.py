from django.apps import AppConfig


class SetitemConfig(AppConfig):
    name = 'setitem'
