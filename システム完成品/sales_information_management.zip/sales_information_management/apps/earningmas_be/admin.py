# from django.contrib import admin
# from .models import EarningInfo

# # admin.site.register(EarningInfo)

# from django.contrib import admin
# # from .models import UserProfile
# from .forms import UserProfileForm

# Register your models here.


# @admin.register(EarningInfo)
# class ServiceAdmin(admin.ModelAdmin):
    # form = UserProfileForm
# @admin.register(Dog)
# class DogAdmin(admin.ModelAdmin):