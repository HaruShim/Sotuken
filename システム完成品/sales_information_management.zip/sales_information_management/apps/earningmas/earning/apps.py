from django.apps import AppConfig


class EarningConfig(AppConfig):
    name = 'earning'
