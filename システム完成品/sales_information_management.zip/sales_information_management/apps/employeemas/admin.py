# from django.contrib import admin
# from .models import EmployeeInfo

# admin.site.register(EmployeeInfo)
