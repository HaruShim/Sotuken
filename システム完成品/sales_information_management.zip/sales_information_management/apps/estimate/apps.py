from django.apps import AppConfig


class EstimateConfig(AppConfig):
    name = 'estimate'
