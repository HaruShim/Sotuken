from django.contrib import admin
from django.contrib.staticfiles.urls import static
from django.urls import path,include

from . import settings

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',include('home.urls')),

    # システムで使用するアプリ
    path('accounts/',include('allauth.urls')),# 従業員マスタ
    path('F01/',include('employeemas.urls')),# 従業員マスタ
    path('F02/',include('storemas.urls')),# 店舗マスタ
    path('F03/',include('itemmas.urls')),# 商品マスタ
    path('F04/',include('earningmas.urls')),# 売上マスタ
    path('F05/',include('benchmas.urls')),# ベンチマークマスタ
    path('F06/',include('bottleneckmas.urls')),# ボトルネックマスタ
    path('F08/',include('setitem.urls')),# セット商品
    path('F09/',include('reserve.urls')),# 取置予約
    path('F10/',include('estimate.urls')),# 見積
    path('F14/',include('workstatus.urls')),# 勤務状況編集
]


# 開発サーバーでメディアを配信できるように設定
urlpatterns += static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)
