from django.apps import AppConfig


class StoremasConfig(AppConfig):
    name = 'storemas'
    verbose_name = '店舗情報マスタ'
