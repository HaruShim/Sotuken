from django.apps import AppConfig


class TamesiformConfig(AppConfig):
    name = 'tamesiform'
