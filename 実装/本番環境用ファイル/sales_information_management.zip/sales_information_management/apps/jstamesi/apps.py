from django.apps import AppConfig


class JstamesiConfig(AppConfig):
    name = 'jstamesi'
