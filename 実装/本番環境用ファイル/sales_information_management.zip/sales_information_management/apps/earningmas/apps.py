from django.apps import AppConfig


class EarningmasConfig(AppConfig):
    name = 'earningmas'
    verbose_name = '売上マスタ'
