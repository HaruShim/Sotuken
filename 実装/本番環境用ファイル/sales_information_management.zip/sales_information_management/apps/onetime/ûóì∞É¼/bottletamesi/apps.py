from django.apps import AppConfig


class BottletamesiConfig(AppConfig):
    name = 'bottletamesi'
