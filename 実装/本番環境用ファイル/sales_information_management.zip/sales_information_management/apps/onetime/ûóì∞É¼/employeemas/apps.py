from django.apps import AppConfig


class EmployeemasConfig(AppConfig):
    name = 'employeemas'
