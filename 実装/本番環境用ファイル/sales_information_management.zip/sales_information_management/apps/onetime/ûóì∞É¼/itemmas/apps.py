from django.apps import AppConfig


class ItemmasConfig(AppConfig):
    name = 'itemmas'
