from django.apps import AppConfig


class EarningmasConfig(AppConfig):
    name = 'earningmas'
