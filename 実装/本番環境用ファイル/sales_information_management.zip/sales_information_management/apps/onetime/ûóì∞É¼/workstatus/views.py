from django.views import generic

class S1401View(generic.TemplateView):
    template_name = "mas_bottleneck_list.html"


