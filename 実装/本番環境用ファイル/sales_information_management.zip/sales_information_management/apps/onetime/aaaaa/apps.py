from django.apps import AppConfig


class AaaaaConfig(AppConfig):
    name = 'aaaaa'
