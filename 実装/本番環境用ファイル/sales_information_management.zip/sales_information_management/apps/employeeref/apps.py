from django.apps import AppConfig


class EmployeerefConfig(AppConfig):
    name = 'employeeref'
