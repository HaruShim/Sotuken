from django.apps import AppConfig


class BottleneckmasConfig(AppConfig):
    name = 'bottleneckmas'
    verbose_name = 'ボトルネックマスタ'
