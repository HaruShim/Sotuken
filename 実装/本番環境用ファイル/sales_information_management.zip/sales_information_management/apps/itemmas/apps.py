from django.apps import AppConfig


class ItemmasConfig(AppConfig):
    name = 'itemmas'
    verbose_name = '商品情報マスタ'
