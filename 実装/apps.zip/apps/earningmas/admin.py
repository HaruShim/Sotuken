from django.contrib import admin
from .models import EarningInfo

admin.site.register(EarningInfo)
