from django.apps import AppConfig


class PrintConfig(AppConfig):
    name = 'print'
