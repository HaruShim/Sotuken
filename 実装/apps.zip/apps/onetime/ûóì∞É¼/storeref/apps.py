from django.apps import AppConfig


class StorerefConfig(AppConfig):
    name = 'storeref'
