from django.apps import AppConfig


class WorkstatusConfig(AppConfig):
    name = 'workstatus'
