from django.views import generic

class S0101View(generic.TemplateView):
    template_name = "mas_bottleneck_list.html"

class S0102View(generic.TemplateView):
    template_name = "mas_bottleneck_register.html"

class S0103View(generic.TemplateView):
    template_name = "mas_bottleneck_edit.html"

class S0104View(generic.TemplateView):
    template_name = "mas_bottleneck_edit.html"

class S0105View(generic.TemplateView):
    template_name = "mas_bottleneck_edit.html"


