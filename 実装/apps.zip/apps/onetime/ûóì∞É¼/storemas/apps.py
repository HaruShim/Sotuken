from django.apps import AppConfig


class StoremasConfig(AppConfig):
    name = 'storemas'
