from django.views import generic

class S1001View(generic.TemplateView):
    template_name = "mas_bottleneck_list.html"

class S1002View(generic.TemplateView):
    template_name = "mas_bottleneck_register.html"


