from django.apps import AppConfig


class TamesiConfig(AppConfig):
    name = 'tamesi'
