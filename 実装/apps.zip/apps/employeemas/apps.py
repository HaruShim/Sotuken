from django.apps import AppConfig


class EmployeemasConfig(AppConfig):
    name = 'employeemas'
    verbose_name = '従業員マスタ'
