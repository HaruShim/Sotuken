from django.contrib import admin
from .models import Bottleneck

admin.site.register(Bottleneck)