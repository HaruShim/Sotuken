from django.apps import AppConfig


class BenchmasConfig(AppConfig):
    name = 'benchmas'
